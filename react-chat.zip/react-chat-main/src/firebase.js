// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyA8OfvydvpOPtdbWkGpwB7oLIvK0Bn2jWg",
  authDomain: "react-chat-57b61.firebaseapp.com",
  projectId: "react-chat-57b61",
  storageBucket: "react-chat-57b61.appspot.com",
  messagingSenderId: "644261460514",
  appId: "1:644261460514:web:13174fabb538c2111e287b",
  measurementId: "G-78M69QVHY2",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);
export const db = getFirestore(app);
